import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-switch-example',
  template: 
  `
  <h1> ngSwitchExample </h1>

<input type="text" #pickcolor>
<button (click)=onClick(pickcolor.value)>pickClolor</button>

  <div [ngSwitch]="color">
    <div *ngSwitchCase="'red'" style="color:red">You picked red colour</div>
    <div *ngSwitchCase="'blue'" style="color:blue">You picked blue colour</div>
    <div *ngSwitchCase="'green'" style="color:green">You picked green colour</div>
    <div *ngSwitchDefault>Pick red, green or blue</div>

  </div>

  
  
  
  `,
  styles: [``]
})
export class NgSwitchExampleComponent implements OnInit {
 
public color = '';
  constructor() { }

  ngOnInit() {
  }

  onClick(color1)
  {
    this.color = color1;
    console.log(this.color);
  }

}
