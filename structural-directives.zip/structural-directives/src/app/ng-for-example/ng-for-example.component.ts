import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-for-example',
  template:
   ` <div style="color:blue">
      <h1> This is the ngForExample </h1>
     </div> 

     <div *ngFor="let color of colors; index as i; first as f">
      <h3>{{color}} {{i}} {{f}}</h3>      
     </div>
   `,
  styles: [``]
})
export class NgForExampleComponent implements OnInit {

  public colors = ["red","green","blue","yellow"];

  constructor() { }

  ngOnInit() {
  }

}
