import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
            <h1> ngIf directive example </h1>
            <h2 *ngIf="istrue; else elseblock">
              codeevolution
            </h2>

            <ng-template #elseblock>
            <h2>
            Name is hidden
            </h2>
            </ng-template>

            <div *ngIf="istrue; then ifblockalternate; else elseblockalternate"></div>

            <ng-template #ifblockalternate>
            <h2>
            This is the if block
            </h2>
            </ng-template>

            <ng-template #elseblockalternate>
            <h2>
            This is the else block
            </h2>
            </ng-template>
            `,
  styles: [``]
})
export class TestComponent implements OnInit {

  public istrue = false;
  constructor() { }

  ngOnInit() {
  }

}
