import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes-example',
  template: 
  `
  <br>
  <br>
  <br>
    <h1>Pipes Example</h1>
   <h2> {{name|lowercase}} </h2>
   <h2> {{name | slice:3:7}}
   <h2>{{person | json}}</h2>
   <br>
   <br>
   <h2>{{5.678 | number:'1.2-3'}}</h2>
   <h2>{{5.678 | number:'3.2-3'}}</h2>
   <h2>{{5.678 | number:'3.1-2'}}</h2>
   <h2>{{0.678 | percent}}</h2>
   <h2>{{5.678 | currency: "INR"}}</h2>
   <h2>{{date | date:'shortDate'}}</h2>
   <h2>{{date | date:'shortTime'}}</h2>

  `,
  styleUrls: ['./pipes-example.component.css']
})
export class PipesExampleComponent implements OnInit {

  public name = "Hello World";
  public person = {
    "firstName":"Dhruv",
    "lastName":"Phansalkar"
  }
  public date = new Date()


  constructor() { }

  ngOnInit() {
  }

}
