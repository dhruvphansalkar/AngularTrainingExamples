import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
            <h2 class="header">Hello {{name}}</h2><br>
            <input [id] = "myId" type="text" value="Dhruv">
            <input [disabled] = "isDisabled" id = {{myId}} type="text" value="Dhruv">
            <p class = "class1"> hello world </p>
            <p [class] = "varclass2"> This is in italics </p>
            <p [class.errorClass] = "hasError"> This class has error</p>
            <p [ngClass]="messageClasses">Using ngClass directive</p>
          
            `,
  styles: [`

  .class1
  {
    color:green;
  }
  .class2
  {
    font-style : italic;
  }
  .errorClass
  {
    color:red;
  }
  
  `]
})
export class TestComponent implements OnInit {

  public name="Dhruv";
  public myId = "TestId";
  public hasError = true;
  public varclass1 = "class1";
  public varclass2 = "class2";
  public isDisabled = true;
  public isSpecial = true;
  public messageClasses = {
                                "class1": !this.hasError,
                                "errorClass": this.hasError,
                                "class2": this.isSpecial
                          }

  public url = window.location.href;
  constructor() { }

  ngOnInit() {
  }

  greetUser()
  {
    return "Hello "  + this.name;
  }

}
