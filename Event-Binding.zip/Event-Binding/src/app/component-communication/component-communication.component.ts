import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'app-component-communication',
  template:
           `
           <h1> Component Communication Example</h1>
           <h2> {{message}} </h2>
           <button (click)="fireEvent()">Send Event</button>

          `,
  styles: [``]
})
export class ComponentCommunicationComponent implements OnInit {
  @Input('parentData') public message
  constructor() { }

 @Output() public childEvent = new EventEmitter();
  
  ngOnInit() {
  }
  fireEvent()
  {
    this.childEvent.emit('From child to parent');
  }

}
