import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `<h1> 2wayBinding & onclick </h1>
            <input [(ngModel)]="name" type="text" #myInput>
            {{name}}
            <button (click)=submit(myInput.value)>log</button>
            `,
  styles: []
})
export class TestComponent implements OnInit {
  public name = "";
  
  constructor() { }

  ngOnInit() {
  }

submit(value)
{
  console.log(value);
  
}

}
